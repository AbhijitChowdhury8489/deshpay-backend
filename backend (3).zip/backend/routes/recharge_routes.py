
from fastapi import APIRouter
from schemas import RechargeRequest

router = APIRouter()

@router.post("/recharge")
def recharge(request: RechargeRequest):
    return {"status": "success", "number": request.number, "amount": request.amount}
