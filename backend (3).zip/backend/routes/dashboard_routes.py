
from fastapi import APIRouter

router = APIRouter()

@router.get("/dashboard")
def dashboard():
    return {
        "total_recharges": 125,
        "total_bills": 88,
        "balance": 5420.00
    }
