
from fastapi import APIRouter, HTTPException
from schemas import UserLogin

router = APIRouter()

@router.post("/login")
def login(user: UserLogin):
    if user.username == "admin" and user.password == "admin123":
        return {"token": "dummy-jwt-token"}
    raise HTTPException(status_code=401, detail="Invalid credentials")
