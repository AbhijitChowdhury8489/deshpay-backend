
from fastapi import APIRouter
from schemas import BillPaymentRequest

router = APIRouter()

@router.post("/bill-payment")
def bill_payment(request: BillPaymentRequest):
    return {"status": "paid", "bill_type": request.bill_type, "account": request.account, "amount": request.amount}
